This project is created for C7 Group Assignment for upGrad PG Course. 

Please use admin:admin to login.