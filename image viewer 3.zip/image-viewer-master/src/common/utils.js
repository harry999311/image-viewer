export const constants = {    
    userInfoUrl:"https://api.instagram.com/v1/users/self",
    userMediaUrl:"https://api.instagram.com/v1/users/self/media/recent"
  }